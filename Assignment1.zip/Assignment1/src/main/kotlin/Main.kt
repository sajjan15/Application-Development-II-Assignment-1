package org.example

fun main() {
    val game = Game()
    game.play()
}